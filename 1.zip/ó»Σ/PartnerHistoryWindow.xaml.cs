﻿using System.Windows;

namespace WpfApp1
{
    public partial class PartnerHistoryWindow : Window
    {
        public PartnerHistoryWindow(Partner partner)
        {
            InitializeComponent();
            // Загрузите историю покупок партнера и отобразите ее в окне
        }
    }
}