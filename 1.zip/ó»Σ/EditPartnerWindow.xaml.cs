﻿using System;
using System.Windows;

namespace WpfApp1
{
    public partial class EditPartnerWindow : Window
    {
        public Partner Partner { get; set; }

        public EditPartnerWindow(Partner partner)
        {
            InitializeComponent();
            Partner = partner;
            DataContext = Partner; // Привязка данных к окну
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true; // Окно закрывается с результатом "true"
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false; // Окно закрывается с результатом "false"
        }
    }
}