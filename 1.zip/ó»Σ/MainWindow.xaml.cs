﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Microsoft.EntityFrameworkCore;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        private TestBaseContext db = new TestBaseContext();
        private List<Partner> partnersList = new List<Partner>();

        public MainWindow()
        {
            InitializeComponent();
            LoadPartners();
        }

        private void LoadPartners()
        {
            partnersList = db.Partners.ToList(); // Загрузка данных из DbSet

            foreach (var a in partnersList)
            {
                a.РейтингСтрокой = "Рейтинг: " + a.Рейтинг;

                var sum = db.Partners_product
                    .Where(y => a.ID == y.ID_Partner)
                    .Sum(x => x.Количество_продукции);

                a.Скидка = CalculateDiscount(sum);
            }

            listPartner.ItemsSource = partnersList;
        }

        private string CalculateDiscount(double? sum)
        {
            if (sum == null) return "0%";

            if (sum < 10000) return "0%";
            if (sum >= 10000 && sum < 50000) return "5%";
            if (sum >= 50000 && sum < 300000) return "10%";
            return "15%";
        }

        private void listPartner_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (listPartner.SelectedItem is Partner selectedPartner)
            {
                // Открытие окна редактирования партнера
                EditPartnerWindow editPartnerWindow = new EditPartnerWindow(selectedPartner);
                if (editPartnerWindow.ShowDialog() == true)
                {
                    try
                    {
                        db.SaveChanges(); // Сохранение изменений в базе данных
                        LoadPartners(); // Обновление списка партнеров
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при сохранении изменений: {ex.Message}");
                    }
                }
            }
        }

        private void btnAddPartner_Click(object sender, RoutedEventArgs e)
        {
            // Открытие окна добавления партнера
            AddPartnerWindow addPartnerWindow = new AddPartnerWindow();
            if (addPartnerWindow.ShowDialog() == true)
            {
                try
                {
                    // Добавление нового партнера в базу данных
                    Partner newPartner = addPartnerWindow.NewPartner;
                    if (newPartner != null)
                    {
                        db.Partners.Add(newPartner);
                        db.SaveChanges();
                        LoadPartners(); // Обновление списка партнеров
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при добавлении партнера: {ex.Message}");
                }
            }
        }

        private void btnProduct_Click(object sender, RoutedEventArgs e)
        {
            // Открытие окна истории покупок партнера
            if (listPartner.SelectedItem is Partner selectedPartner)
            {
                PartnerHistoryWindow historyWindow = new PartnerHistoryWindow(selectedPartner);
                historyWindow.Show();
            }
            else
            {
                MessageBox.Show("Выберите партнера для просмотра истории.");
            }
        }

        private void btnDeletePartner_Click(object sender, RoutedEventArgs e)
        {
            // Удаление партнера
            if (listPartner.SelectedItem is Partner selectedPartner)
            {
                MessageBoxResult result = MessageBox.Show($"Вы уверены, что хотите удалить партнера {selectedPartner.Наименование_партнера}?", "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        db.Partners.Remove(selectedPartner);
                        db.SaveChanges();
                        LoadPartners(); // Обновление списка партнеров
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при удалении партнера: {ex.Message}");
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите партнера для удаления.");
            }
        }
    }
}