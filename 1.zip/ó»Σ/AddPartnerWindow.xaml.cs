﻿using System;
using System.Windows;

namespace WpfApp1
{
    public partial class AddPartnerWindow : Window
    {
        public Partner NewPartner { get; set; }

        public AddPartnerWindow()
        {
            InitializeComponent();
            NewPartner = new Partner();
            DataContext = NewPartner; // Привязка данных к окну
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true; // Окно закрывается с результатом "true"
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false; // Окно закрывается с результатом "false"
        }
    }
}