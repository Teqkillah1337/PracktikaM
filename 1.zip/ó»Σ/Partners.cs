using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WpfApp1
{
    public class Partner
    {
        [Key]
        public int ID { get; set; }

        public string Тип_партнера { get; set; }
        public string Наименование_партнера { get; set; }
        public string Директор { get; set; }
        public string Электронная_почта_партнера { get; set; }
        public string Телефон_партнера { get; set; }
        public string Юридический_адрес_партнера { get; set; }
        public long? ИНН { get; set; }
        public double? Рейтинг { get; set; }

        [NotMapped]
        public string Скидка { get; set; } // Для отображения скидки в UI

        [NotMapped]
        public string РейтингСтрокой { get; set; } // Для отображения рейтинга в UI

        public virtual ICollection<Partners_product> Partners_Products { get; set; } = new List<Partners_product>();
    }
}