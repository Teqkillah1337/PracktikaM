﻿using Microsoft.EntityFrameworkCore;

namespace WpfApp1
{
    public class TestBaseContext : DbContext
    {
        public DbSet<Partner> Partners { get; set; }
        public DbSet<Partners_product> Partners_product { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Material_type> Material_types { get; set; }
        public DbSet<Product_type> Product_types { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=DESKTOP-2VMC5H5\\SQLEXPRESS;Initial Catalog=TestBase;Integrated Security=True;");
        }
    }
}