﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace Master_floor
{
    public partial class History : Window
    {
        private TestBaseEntities db = new TestBaseEntities();
        private int partnerId;

        public History(int partnerId)
        {
            InitializeComponent();
            this.partnerId = partnerId;
            LoadSalesHistory();
        }

        private void LoadSalesHistory()
        {
            List<Partners_product> sales = db.Partners_product
                .Where(sp => sp.ID_Partner == partnerId)
                .ToList();

            lvSalesHistory.ItemsSource = sales;
        }
    }
}