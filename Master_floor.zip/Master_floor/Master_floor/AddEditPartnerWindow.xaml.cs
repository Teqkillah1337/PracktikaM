﻿using System;
using System.Windows;

namespace Master_floor
{
    public partial class AddEditPartnerWindow : Window
    {
        private TestBaseEntities db = new TestBaseEntities();
        private Partners partner; // Changed Partner to Partners

        public AddEditPartnerWindow() // Constructor for adding a new partner
        {
            InitializeComponent();
            partner = new Partners(); // Changed Partner to Partners
        }

        public AddEditPartnerWindow(int partnerId) // Constructor for editing an existing partner
        {
            InitializeComponent();
            partner = db.Partners.Find(partnerId);
            if (partner == null)
            {
                MessageBox.Show("Партнер не найден.");
                DialogResult = false;
                Close();
                return;
            }
            LoadPartnerData();
        }

        private void LoadPartnerData()
        {
            txtТипПартнера.Text = partner.Тип_партнера;
            txtНаименованиеПартнера.Text = partner.Наименование_партнера;
            txtДиректор.Text = partner.Директор;
            txtEmail.Text = partner.Электронная_почта_партнера;
            txtТелефон.Text = partner.Телефон_партнера;
            txtАдрес.Text = partner.Юридический_адрес_партнера;
            txtИНН.Text = partner.ИНН.ToString();
            txtРейтинг.Text = partner.Рейтинг.ToString();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                partner.Тип_партнера = txtТипПартнера.Text;
                partner.Наименование_партнера = txtНаименованиеПартнера.Text;
                partner.Директор = txtДиректор.Text;
                partner.Электронная_почта_партнера = txtEmail.Text;
                partner.Телефон_партнера = txtТелефон.Text;
                partner.Юридический_адрес_партнера = txtАдрес.Text;

                if (double.TryParse(txtИНН.Text, out double inn))
                {
                    partner.ИНН = inn;
                }
                else
                {
                    MessageBox.Show("Неверный формат ИНН.");
                    return;
                }

                if (double.TryParse(txtРейтинг.Text, out double rating))
                {
                    partner.Рейтинг = rating;
                }
                else
                {
                    MessageBox.Show("Неверный формат рейтинга.");
                    return;
                }

                if (partner.ID == 0) // Adding a new partner
                {
                    db.Partners.Add(partner);
                }

                db.SaveChanges();
                DialogResult = true; // Indicate success
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}");
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false; // Indicate cancellation
            Close();
        }
    }
}