﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Input;

namespace Master_floor
{
    public partial class MainWindow : Window
    {
        TestBaseEntities db = new TestBaseEntities();
        private List<PartnerWithDiscount> partnerList; // Added to store calculated partner data

        public MainWindow()
        {
            InitializeComponent();
            LoadPartners();
        }

        private void LoadPartners()
        {
            partnerList = CalculatePartnerDiscounts(db.Partners.ToList());
            listPartner.ItemsSource = partnerList;
        }

        private List<PartnerWithDiscount> CalculatePartnerDiscounts(List<Partners> partners)
        {
            var partnerDiscounts = new List<PartnerWithDiscount>();

            foreach (var partner in partners)
            {
                var totalSales = db.Partners_product.Where(pp => pp.ID_Partner == partner.ID).Sum(pp => (double?)pp.Количество_продукции) ?? 0; // Handle nulls
                string discount = CalculateDiscount(totalSales);

                partnerDiscounts.Add(new PartnerWithDiscount
                {
                    ID = partner.ID,
                    Тип_партнера = partner.Тип_партнера,
                    Наименование_партнера = partner.Наименование_партнера,
                    Директор = partner.Директор,
                    Телефон_партнера = partner.Телефон_партнера,
                    Рейтинг = "Рейтинг: " + partner.Рейтинг,
                    Скидка = discount
                });
            }

            return partnerDiscounts;
        }


        private string CalculateDiscount(double totalSales)
        {
            if (totalSales < 10000) return "0%";
            if (totalSales < 50000) return "5%";
            if (totalSales < 300000) return "10%";
            return "15%";
        }

        private void listPartner_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (listPartner.SelectedItem is PartnerWithDiscount selectedPartner)
            {
                EditPartner(selectedPartner.ID);
            }
        }

        private void btnAddPartner_Click(object sender, RoutedEventArgs e)
        {
            var addEditPartnerWindow = new AddEditPartnerWindow();
            if (addEditPartnerWindow.ShowDialog() == true)
            {
                LoadPartners(); // Refresh the list after adding
            }
        }

        private void btnEditPartner_Click(object sender, RoutedEventArgs e)
        {
            if (listPartner.SelectedItem is PartnerWithDiscount selectedPartner)
            {
                EditPartner(selectedPartner.ID);
            }
            else
            {
                MessageBox.Show("Выберите партнера для редактирования.");
            }
        }

        private void EditPartner(int partnerId)
        {
            var addEditPartnerWindow = new AddEditPartnerWindow(partnerId);
            if (addEditPartnerWindow.ShowDialog() == true)
            {
                LoadPartners(); // Refresh the list after editing
            }
        }

        private void btnDeletePartner_Click(object sender, RoutedEventArgs e)
        {
            if (listPartner.SelectedItem is PartnerWithDiscount selectedPartner)
            {
                if (MessageBox.Show($"Вы уверены, что хотите удалить партнера '{selectedPartner.Наименование_партнера}'?", "Подтверждение удаления", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    try
                    {
                        var partnerToDelete = db.Partners.Find(selectedPartner.ID);
                        if (partnerToDelete != null)
                        {
                            //Remove related entries from Partners_Product
                            var relatedProducts = db.Partners_product.Where(p => p.ID_Partner == partnerToDelete.ID);
                            db.Partners_product.RemoveRange(relatedProducts);

                            db.Partners.Remove(partnerToDelete);
                            db.SaveChanges();
                            LoadPartners(); // Refresh the list after deleting
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при удалении партнера: {ex.Message}");
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите партнера для удаления.");
            }
        }

        private void btnProduct_Click(object sender, RoutedEventArgs e)
        {
            if (listPartner.SelectedItem is PartnerWithDiscount selectedPartner)
            {
                var historyWindow = new History(selectedPartner.ID);
                historyWindow.Show();
            }
            else
            {
                MessageBox.Show("Выберите партнера, чтобы посмотреть историю.");
            }
        }
    }

    //Helper class to combine partner data with discount calculation
    public class PartnerWithDiscount : Partners  // Inherit from Partner entity
    {
        public string Скидка { get; set; }
        public string Рейтинг { get; set; }
    }
}